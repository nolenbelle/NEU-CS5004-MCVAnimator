package cs5004.animator.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.*;
import cs5004.animator.controller.AnimationController;

/**
 * JFrame class to contain the composite view PlaybackView & PlaybackUI.
 *
 * We could also maybe add this all into myFrame?
 */
public class CompositeFrame extends JFrame {
  private PlaybackView view; // can't be AnimationView interface type bc we need it to be a JPanel
  private PlaybackUI ui; // the options for the user
//  private JList<ButtonEvent> buttonList; // gotten from the UI -> these are the possible buttons
//  private ButtonEvent[] buttons = {ButtonEvent.PLAY, ButtonEvent.PAUSE, ButtonEvent.FASTER,
//  ButtonEvent.SLOWER, ButtonEvent.LOOP};
  private int speed;

  /**
   * Constructor of the frame to animate in.
   * @param eventLog model event log
   * @param speed speed of play
   */
  public CompositeFrame(List<String> eventLog, int speed) {
    this.speed = 1000;
    //TAKE THIS OUT
    //this.setSize(1000,1000);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JPanel container = new JPanel();
    container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS)); // stack  our panels
    view = new PlaybackView(eventLog, speed); // call however we need to call the new view
    ui = new PlaybackUI();


    container.add(view); // top
    container.add(ui); // bottom

    this.add(container);
    //TAKE THIS OUT
    //this.setVisible(true);
  }

  public void clickButton(String button) {
    if (button.equals("play")) {
      ui.clickPlay();
      this.view.play();
    }
    if (button.equals("pause")) {
      ui.clickPause();
      this.view.pause();
    }
    if (button.equals("loop")) {
      ui.clickLoop();
      this.view.loop(this);
    }
    if (button.equals("faster")) {
      ui.clickPlay();
      this.view.faster();
    }
    if (button.equals("slower")) {
      ui.clickPause();
      this.view.slower();
    }
    if (button.equals("rewind")) { // restart
      ui.clickLoop();
      this.view.rewind();
      this.dispose();
    }
  }

  public void setListener(AnimationController controller) {
    ui.setListener(controller);
  }
}

